﻿// 필요한 네임스페이스 추가
using System;
using System.Linq;
using System.Windows.Controls;
using System.Windows.Threading;
using InTheHand.Net;
using InTheHand.Net.Bluetooth;
using InTheHand.Net.Sockets;
using System.Threading;

namespace SFARM.Views
{
    public partial class PanelLiveInfo : UserControl
    {
        private BluetoothClient bluetoothClient;
        private const string DEVICE_NAME = "SSFARM";  // Bluetooth 장치 이름

        public PanelLiveInfo()
        {
            InitializeComponent();

            // Bluetooth 클라이언트 초기화
            bluetoothClient = new BluetoothClient();

            // Bluetooth 장치 찾기
            BluetoothDeviceInfo[] devices = bluetoothClient.DiscoverDevices();
            BluetoothDeviceInfo device = devices.FirstOrDefault(d => d.DeviceName == DEVICE_NAME);

            if (device != null)
            {
                // Bluetooth 장치가 발견되면 RFCOMM 소켓 열기
                BluetoothAddress address = device.DeviceAddress;
                BluetoothEndPoint endPoint = new BluetoothEndPoint(address, BluetoothService.SerialPort);
                BluetoothClient client = new BluetoothClient();
                client.Connect(endPoint);

                // 데이터 수신을 위해 스레드 생성
                Thread receiveThread = new Thread(ReceiveData);
                receiveThread.Start(client);
            }
            else
            {
                Console.WriteLine("Bluetooth 장치를 찾을 수 없습니다.");
            }
        }

        private void ReceiveData(object obj)
        {
            BluetoothClient client = (BluetoothClient)obj;

            try
            {
                // 데이터를 계속 수신
                while (true)
                {
                    byte[] buffer = new byte[256];
                    int bytesRead = client.GetStream().Read(buffer, 0, buffer.Length);
if (bytesRead > 0)
                    {
                        string data = System.Text.Encoding.UTF8.GetString(buffer, 0, bytesRead);
                        Console.WriteLine("Received: " + data); // 디버깅을 위해 수신된 데이터 출력

                        // UI 업데이트를 위해 Dispatcher를 사용하여 메인 쓰레드에서 실행
                        Dispatcher.Invoke(() =>
                        {
                            // 수신된 데이터를 파싱하여 각 라벨에 표시
                            string[] dataParts = data.Split(',');

                            if (dataParts.Length == 5)
                            {
                                string soilMoisturePart = dataParts[0].Split(':')[1].Trim();
                                string tempPart = dataParts[1].Split(':')[1].Trim();
                                string humidPart = dataParts[2].Split(':')[1].Trim();
                                string lightPart = dataParts[3].Split(':')[1].Trim();
                                string waterPart = dataParts[4].Split(':')[1].Trim();


                                lblSoilMoisture.Content = soilMoisturePart + "%";
                                lblTemperature.Content = tempPart + "˚C";
                                //lblHumidity.Content = humidPart + "%";
                                lblLight.Content = lightPart + "lux";
                                lblWater.Content = waterPart;

                            }
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error receiving data: " + ex.Message);
            }
            finally
            {
                // 연결 종료
                client.Close();
            }
        }
    }
}
