﻿using InTheHand.Net.Bluetooth;
using InTheHand.Net;
using InTheHand.Net.Sockets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SFARM.Views
{
    /// <summary>
    /// PanelControl.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class PanelControl : UserControl
    {
        private BluetoothClient bluetoothClient;
        private const string DEVICE_NAME = "SSFARM";  // Bluetooth 장치 이름

        public PanelControl()
        {
            InitializeComponent();
            // Bluetooth 클라이언트 초기화
            bluetoothClient = new BluetoothClient();

            // Bluetooth 장치 찾기
            BluetoothDeviceInfo[] devices = bluetoothClient.DiscoverDevices();
            BluetoothDeviceInfo device = devices.FirstOrDefault(d => d.DeviceName == DEVICE_NAME);

            if (device != null)
            {
                // Bluetooth 장치가 발견되면 RFCOMM 소켓 열기
                BluetoothAddress address = device.DeviceAddress;
                BluetoothEndPoint endPoint = new BluetoothEndPoint(address, BluetoothService.SerialPort);
                BluetoothClient client = new BluetoothClient();
                client.Connect(endPoint);

                // 데이터 수신을 위해 스레드 생성
                Thread receiveThread = new Thread(ReceiveData);
                receiveThread.Start(client);
            }
            else
            {
                Console.WriteLine("Bluetooth 장치를 찾을 수 없습니다.");
            }
        }
        private void ReceiveData(object clientObject)
        {
            BluetoothClient client = (BluetoothClient)clientObject;
            while (true)
            {
                try
                {
                    if (client.Connected)
                    {
                        byte[] buffer = new byte[256];
                        int bytesRead = client.GetStream().Read(buffer, 0, buffer.Length);
                        string data = System.Text.Encoding.ASCII.GetString(buffer, 0, bytesRead);
                        Dispatcher.Invoke(() => {
                            // 수신된 데이터를 UI에 표시하거나 처리
                            Console.WriteLine(data);
                        });
                    }
                }
                catch (Exception ex)
                {
                    Dispatcher.Invoke(() => {
                        MessageBox.Show("데이터 수신 중 오류 발생: " + ex.Message);
                    });
                    break;
                }
            }
        }

        private void SendCommand(char command)
        {
            if (bluetoothClient.Connected)
            {
                byte[] buffer = new byte[] { (byte)command };
                bluetoothClient.GetStream().Write(buffer, 0, buffer.Length);
            }
        }

        private void OffRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            SendCommand('0');
        }

        private void LowRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            SendCommand('1');
        }

        private void MediumRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            SendCommand('2');
        }

        private void HighRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            SendCommand('3');
        }
    }
}

