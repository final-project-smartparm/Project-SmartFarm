﻿using System;
using System.Windows.Controls;

namespace SFARM.Views
{
    public partial class PanelControl : UserControl
    {
        public PanelControl()
        {
            InitializeComponent();

            // 싱글톤 BluetoothManager 인스턴스 사용
            BluetoothManager bluetoothManager = BluetoothManager.Instance;

            // BluetoothManager의 DataReceived 이벤트를 구독
            bluetoothManager.DataReceived += OnDataReceived;
        }

        // 데이터 수신 시 UI를 업데이트하는 메소드
        private void OnDataReceived(string data)
        {
            Dispatcher.Invoke(() =>
            {
                // 수신된 데이터를 파싱하고 UI를 업데이트
                string[] dataParts = data.Split(',');

                if (dataParts.Length == 5)
                {
                    string soilMoisturePart = dataParts[0].Split(':')[1].Trim();
                    string tempPart = dataParts[1].Split(':')[1].Trim();
                    string humidPart = dataParts[2].Split(':')[1].Trim();
                    string lightPart = dataParts[3].Split(':')[1].Trim();
                    string waterPart = dataParts[4].Split(':')[1].Trim();

                    // 여기서 라벨 또는 다른 UI 요소를 업데이트
                }
            });
        }
    }
}
