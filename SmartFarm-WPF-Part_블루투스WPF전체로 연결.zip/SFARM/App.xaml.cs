﻿using System.Windows;

namespace SFARM
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // BluetoothManager 인스턴스 초기화
            BluetoothManager bluetoothManager = BluetoothManager.Instance;
        }
    }
}
