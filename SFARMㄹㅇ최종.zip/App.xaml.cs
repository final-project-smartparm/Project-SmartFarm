﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace SFARM
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public App()
        {
            Syncfusion.Licensing.SyncfusionLicenseProvider.RegisterLicense("MzM3NjIzMUAzMjM2MmUzMDJlMzBlV2kzSlFvdjJLS0RVbWV2SC9zcUtSY204K0RIWGtxUmNuc0ZIRElmUVBFPQ==");
        }
    }
}
