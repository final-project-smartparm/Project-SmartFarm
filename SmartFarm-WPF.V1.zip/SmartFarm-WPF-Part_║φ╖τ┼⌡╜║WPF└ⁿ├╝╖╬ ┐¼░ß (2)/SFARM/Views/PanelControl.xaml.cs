﻿using System;
using System.Windows.Controls;

namespace SFARM.Views
{
    public partial class PanelControl : UserControl
    {
        public PanelControl()
        {
            InitializeComponent();

        }

    }
}
